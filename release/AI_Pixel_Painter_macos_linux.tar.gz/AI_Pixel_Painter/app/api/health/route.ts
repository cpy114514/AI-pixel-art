import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    name: "ai-pixel-art",
    app: "AI Pixel Art",
  });
}
